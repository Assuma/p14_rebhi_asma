package enumerations;

public enum AnnoDiStudi {
	T1, T2, T3, M1, M2, D
}
