package enumerations;

public enum TipoPianoStudi {
	tempoPieno, tempoParizale
}
