package enumerations;
 
/**
 * 
 * @author assma
 */


/*Enumerations tipo piano di studi tempoPieno, tempoParizale*/
public enum TipoPianoStudi {
	tempoPieno, tempoParizale
}
