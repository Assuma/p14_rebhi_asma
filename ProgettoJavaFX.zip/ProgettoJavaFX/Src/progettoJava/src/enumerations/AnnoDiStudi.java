package enumerations;

/**
 * 
 * @author assma
 */ 

/*Enumerations dell'anno di studi T1:Triennale1,2,3 e M1 Magistrale M1,M2*/
public enum AnnoDiStudi {
	T1, T2, T3, M1, M2, D
}
